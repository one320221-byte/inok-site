// INOK для Chrome: включает HTTPS-прокси INOK для браузера и сам отвечает на запрос логина прокси.
// Адрес API подставляется при сборке (build_ext.py). Всё состояние лежит в chrome.storage.local.
const API = "https://inokapp.duckdns.org";
const BYPASS_RU = ["*.ru", "*.su", "*.xn--p1ai", "*.by", "*.kz"];
const LOCAL = ["localhost", "127.0.0.1", "<local>", "10.0.0.0/8", "192.168.0.0/16", "172.16.0.0/12"];

const get = (keys) => chrome.storage.local.get(keys);
const set = (obj) => chrome.storage.local.set(obj);

async function fetchConfig(key) {
  const r = await fetch(API + "/api/ext/config", { headers: { "X-Key": key }, cache: "no-store" });
  if (r.status === 401) return { error: "bad_key" };
  if (!r.ok) throw new Error("http " + r.status);
  return r.json();
}

async function applyProxy() {
  const { on, cfg, bypassRu = true } = await get(["on", "cfg", "bypassRu"]);
  if (on && cfg && cfg.active && cfg.host) {
    await chrome.proxy.settings.set({
      scope: "regular",
      value: {
        mode: "fixed_servers",
        rules: {
          singleProxy: { scheme: "https", host: cfg.host, port: cfg.port },
          bypassList: LOCAL.concat(bypassRu ? BYPASS_RU : []),
        },
      },
    });
  } else {
    await chrome.proxy.settings.clear({ scope: "regular" });
  }
  await paintIcon();
}

async function paintIcon() {
  const { on, cfg } = await get(["on", "cfg"]);
  const lit = !!(on && cfg && cfg.active);
  const v = lit ? "on" : "off";
  await chrome.action.setIcon({ path: { 16: `icons/${v}16.png`, 32: `icons/${v}32.png` } });
  await chrome.action.setBadgeText({ text: cfg && !cfg.active ? "!" : "" });
  await chrome.action.setBadgeBackgroundColor({ color: "#F0B44C" });
  await chrome.action.setTitle({ title: lit ? "INOK: включён" : "INOK: выключен" });
}

// Обновить срок и пароль с сервера. Возвращает свежий cfg или объект с ошибкой.
async function refresh() {
  const { key } = await get(["key"]);
  if (!key) return { error: "no_key" };
  let cfg;
  try { cfg = await fetchConfig(key); }
  catch (e) { return { error: "offline" }; }
  if (cfg.error) {
    await set({ cfg: null, on: false });
    await applyProxy();
    return cfg;
  }
  await set({ cfg, checkedAt: Date.now() });
  if (!cfg.active) await set({ on: false });
  await applyProxy();
  return cfg;
}

// Прокси просит логин: отдаём номер аккаунта и ключ. Один запрос — одна попытка, чтобы не зациклиться.
const tried = new Set();
chrome.webRequest.onAuthRequired.addListener(
  (details, done) => {
    if (!details.isProxy || tried.has(details.requestId)) return done({});
    tried.add(details.requestId);
    get(["cfg", "on"]).then(({ cfg, on }) => {
      if (on && cfg && cfg.host && details.challenger && details.challenger.host === cfg.host) {
        done({ authCredentials: { username: cfg.username, password: cfg.password } });
      } else done({});
    });
  },
  { urls: ["<all_urls>"] },
  ["asyncBlocking"]
);
chrome.webRequest.onCompleted.addListener((d) => tried.delete(d.requestId), { urls: ["<all_urls>"] });
chrome.webRequest.onErrorOccurred.addListener((d) => tried.delete(d.requestId), { urls: ["<all_urls>"] });

chrome.proxy.onProxyError.addListener((e) => set({ lastError: { at: Date.now(), error: e.error } }));

chrome.alarms.create("refresh", { periodInMinutes: 60 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "refresh") refresh(); });
chrome.runtime.onStartup.addListener(() => { applyProxy(); refresh(); });
chrome.runtime.onInstalled.addListener(() => { applyProxy(); });

// Сообщения из окошка расширения
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  (async () => {
    if (msg.type === "login") {
      await set({ key: msg.key });
      const cfg = await refresh();
      if (!cfg.error && cfg.active) { await set({ on: true }); await applyProxy(); }
      reply(cfg);
    } else if (msg.type === "toggle") {
      await set({ on: !!msg.on });
      await applyProxy();
      reply({ ok: true });
    } else if (msg.type === "bypass") {
      await set({ bypassRu: !!msg.value });
      await applyProxy();
      reply({ ok: true });
    } else if (msg.type === "refresh") {
      reply(await refresh());
    } else if (msg.type === "logout") {
      await chrome.storage.local.clear();
      await applyProxy();
      reply({ ok: true });
    }
  })();
  return true;  // ответ придёт асинхронно
});
