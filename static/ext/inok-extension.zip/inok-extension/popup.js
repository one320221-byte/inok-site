// Окошко расширения: вход по ключу, свеча-выключатель, срок, обход российских сайтов.
const BOT = "https://t.me/inokvpn_bot";
const root = document.getElementById("root");
const send = (msg) => chrome.runtime.sendMessage(msg);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"];
const date = (ts) => { const d = new Date(ts * 1000); return `${d.getDate()} ${MONTHS[d.getMonth()]}`; };
const plural = (n, a, b, c) => { const x = n % 10, y = n % 100; return x === 1 && y !== 11 ? a : x >= 2 && x <= 4 && (y < 10 || y >= 20) ? b : c; };

function candle(lit) {
  return `<svg viewBox="0 0 96 132" width="96" height="132" aria-hidden="true">
    <defs><radialGradient id="h"><stop offset="0" stop-color="#F0B44C" stop-opacity=".55"/><stop offset="1" stop-color="#F0B44C" stop-opacity="0"/></radialGradient>
    <linearGradient id="w" x1="0" x2="1"><stop offset="0" stop-color="#cfcabf"/><stop offset=".45" stop-color="#E6E3DC"/><stop offset="1" stop-color="#a9a499"/></linearGradient></defs>
    ${lit ? `<ellipse class="halo" cx="48" cy="30" rx="30" ry="30" fill="url(#h)"/>
      <path class="flame" d="M48 8C54 18 58 24 58 31 58 38 53 42 48 42 43 42 38 38 38 31 38 24 42 18 48 8Z" fill="#F0B44C"/>
      <path class="flame" d="M48 22C50.5 27 52 30 52 33 52 36 50 38 48 38 46 38 44 36 44 33 44 30 45.5 27 48 22Z" fill="#fff4d6"/>`
    : `<path class="smoke" d="M48 40C43 30 53 24 48 14 44 6 51 2 49-4" fill="none" stroke="#8F8B82" stroke-width="2" stroke-linecap="round"/>`}
    <rect x="47" y="40" width="2" height="7" rx="1" fill="#2a2723"/>
    <rect class="wax" x="33" y="46" width="30" height="76" rx="5" fill="url(#w)"/>
    <rect x="14" y="122" width="68" height="6" rx="3" fill="#2a2723"/>
  </svg>`;
}

async function load() {
  const s = await chrome.storage.local.get(["key", "cfg", "on", "bypassRu", "checkedAt", "lastError"]);
  if (!s.key || !s.cfg) return login(s.key);
  main(s);
  // раз в 10 минут при открытии окна сверяем срок с сервером
  if (!s.checkedAt || Date.now() - s.checkedAt > 10 * 60 * 1000) {
    const cfg = await send({ type: "refresh" });
    if (cfg && !cfg.error) main(await chrome.storage.local.get(["key", "cfg", "on", "bypassRu", "lastError"]));
    else if (cfg && cfg.error === "bad_key") login("", "Ключ больше не действует. Возьмите новый в боте.");
  }
}

function login(prefill = "", error = "") {
  root.innerHTML = `<div class="top"><span class="brand">INOK</span><small>для Chrome</small></div>
    <h1>Введите ключ</h1>
    <p>Ключ есть в боте INOK: «Расширение для Chrome» или вкладка «Подключить» в приложении.</p>
    <form id="f">
      <input id="k" autocomplete="off" spellcheck="false" maxlength="24" placeholder="XXXX-XXXX-XXXX-XXXX" value="${esc(prefill)}" aria-label="Ключ">
      <div class="err" id="e" role="alert">${esc(error)}</div>
      <div class="stack"><button class="btn btn-gold" type="submit" id="go">Войти и включить</button>
      <a class="btn btn-line" href="${BOT}?start=ext" target="_blank" rel="noopener">Получить ключ в боте</a></div>
    </form>`;
  const k = document.getElementById("k");
  k.focus();
  document.getElementById("f").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const key = k.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
    const e = document.getElementById("e");
    if (key.length !== 16) { e.textContent = "В ключе 16 символов: буквы и цифры."; return; }
    const go = document.getElementById("go");
    go.disabled = true; go.textContent = "Проверяем…";
    const cfg = await send({ type: "login", key });
    go.disabled = false; go.textContent = "Войти и включить";
    if (cfg.error === "bad_key") e.textContent = "Такого ключа нет. Проверьте, нет ли опечатки.";
    else if (cfg.error) e.textContent = "Нет связи с INOK. Проверьте интернет.";
    else load();
  });
}

function main(s) {
  const cfg = s.cfg;
  const lit = !!(s.on && cfg.active);
  const now = Date.now() / 1000;
  const left = Math.max(0, Math.ceil((cfg.expires_at - now) / 86400));
  const bypass = s.bypassRu !== false;
  const recentErr = s.lastError && Date.now() - s.lastError.at < 60 * 1000 && lit;
  root.innerHTML = `<div class="top"><span class="brand">INOK</span><small>${esc(cfg.account)}</small></div>
    <section class="altar ${lit ? "" : "off"}">
      <button class="switch" id="sw" aria-pressed="${lit}" ${cfg.active ? "" : "disabled"} title="${lit ? "Выключить" : "Включить"}">${candle(lit)}</button>
      <div class="status">${lit ? "Защита включена" : cfg.active ? "Выключено" : "Срок закончился"}</div>
      <div class="hint">${cfg.active ? (lit ? "Нажмите на свечу, чтобы погасить" : "Нажмите на свечу, чтобы зажечь") : "Продлите доступ в боте, и расширение заработает"}</div>
    </section>
    ${recentErr ? `<p class="alert">Сервер не ответил. Если сайты не открываются, выключите и включите снова.</p>` : ""}
    <div class="row"><span>Доступ${cfg.active ? `<small>до ${date(cfg.expires_at)}</small>` : ""}</span><b>${cfg.active ? `${left} ${plural(left, "день", "дня", "дней")}` : "закончился"}</b></div>
    <div class="row"><span>Свои сайты напрямую<small>.ru, .рф, .kz, .by без VPN: банки не ругаются</small></span>
      <button class="tgl" id="bp" role="switch" aria-checked="${bypass}" aria-label="Российские сайты напрямую"></button></div>
    ${cfg.active && left > 5 ? "" : `<div class="stack"><a class="btn btn-gold" href="${esc(cfg.bot || BOT)}" target="_blank" rel="noopener">Продлить в боте</a></div>`}
    <div class="foot"><a href="${BOT}" target="_blank" rel="noopener">Бот INOK</a><button id="out">Выйти</button></div>`;
  document.getElementById("sw").addEventListener("click", async () => { await send({ type: "toggle", on: !lit }); load(); });
  document.getElementById("bp").addEventListener("click", async () => { await send({ type: "bypass", value: !bypass }); load(); });
  document.getElementById("out").addEventListener("click", async () => { await send({ type: "logout" }); load(); });
}

load();
